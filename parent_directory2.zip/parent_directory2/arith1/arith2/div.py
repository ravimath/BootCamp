def div(a,b):
    print("division",a/b)
