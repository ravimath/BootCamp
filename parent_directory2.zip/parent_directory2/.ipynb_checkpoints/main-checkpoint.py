from arith1 import add
from arith1 import sud
from arith1.arith2 import mul
from arith1.arith2 import div
from arith1.arith2 import dimul
loop=1
choice=1
while loop == 1:
    print ("Welcome")
    print ("your options are:")
    print ()
    print("1) Addition")
    print("2) Subtraction")
    print("3) Multiplication")
    print("4) Division")
    print("5) Modulus")
    print("6) Quit calculator.py")
    print("")
    try:
        choice = int(input("Choose your option:"))
    except: 
        print("please enter a valid number for option")
    print("")
    print("")
    if choice == 1:
        a = int(input("Enter 1st number: "))
        b = int(input("Enter 2nd number:"))
        add.add(a,b) 
    elif choice == 2:
        a = int(input("Enter 1st number: "))
        b = int(input("Enter 2nd number:"))
        from arith1 import sub 
        sub.sub(a,b)
    elif choice == 3:
        a = int(input("Enter 1st number: "))
        b = int(input("Enter 2nd number: "))
        from arith1.arith2 import mul 
        mul.mul(a,b)
    elif choice == 4:
        a = int(input("Enter 1st number: "))
        b = int(input("Enter 2nd number:"))
        from arith1.arith2 import div 
        div.div(a,b)
    elif choice == 5:
        a = int(input("Enter 1st number: "))
        b = int(input("Enter 2nd number:"))
        from arith1.arith2 import muldiv 
        muldiv.muldiv(a,b)    
    elif choice == 5:
        loop = 0
    else:
        print("please choice a valid option from 1 to 5")
        choice=0
print ("Thank-you for using calculator.py!")
